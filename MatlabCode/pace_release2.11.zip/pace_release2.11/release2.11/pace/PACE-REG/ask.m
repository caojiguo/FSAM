%function ask is used to paused the current running program
%so that, one can view graph one at a time
function ask() 
     input('Press any key to continue ...', 's');
end
